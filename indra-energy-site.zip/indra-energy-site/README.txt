Upload index.html to GitHub. .gitignore is optional. Then import the repo into Vercel.
